#include <stdio.h>
/* Nathan Lisboa / 17/10
Explicar a diferença de dois programas  */
int main(void) {
  printf("A diferença dos dois códigos é o que eles vao usar pra fazer as contas, no primeiro faz uso do conteúdo do ponteiro e entao no fim printa 15 por conta do for, já no outro ele trabalha com o endereço do ponteiro e no fim vai printar o endereço mais 5 posições graças ao for. \n");
  return 0;
}